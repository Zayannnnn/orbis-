require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const multer = require('multer');
const path = require('path');
const bcrypt = require('bcrypt');
const cors = require('cors');

// Initialize express app
const app = express();

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(express.static('uploads'));

// Connect to MongoDB
mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('Connected to MongoDB'))
  .catch(err => console.error('Error connecting to MongoDB:', err));

// Multer setup for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, 'uploads/'),
  filename: (req, file, cb) => cb(null, Date.now() + path.extname(file.originalname)),
});
const upload = multer({ storage });

// Models
const User = mongoose.model('User', new mongoose.Schema({
  name: String,
  email: { type: String, unique: true },
  password: String,
  location: String,
}));

const Product = mongoose.model('Product', new mongoose.Schema({
  name: String,
  price: Number,
  location: String,
  image: String,
  type: { type: String, enum: ['sell', 'rent'] },
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
}));

// Routes
app.post('/users/register', async (req, res) => {
  const { name, email, password, location } = req.body;
  const existingUser = await User.findOne({ email });
  if (existingUser) return res.status(400).send('User already exists');

  const hashedPassword = await bcrypt.hash(password, 10);
  const newUser = new User({ name, email, password: hashedPassword, location });
  await newUser.save();
  res.status(201).send('User created');
});

app.post('/users/login', async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email });
  if (!user) return res.status(400).send('User not found');

  const match = await bcrypt.compare(password, user.password);
  if (!match) return res.status(400).send('Invalid password');

  res.status(200).send({ message: 'Login successful', user });
});

app.post('/products/add', upload.single('image'), async (req, res) => {
  const { name, price, location, type, userId } = req.body;
  const image = req.file ? req.file.filename : null;

  const product = new Product({
    name,
    price,
    location,
    type,
    image: image ? `/uploads/${image}` : null,
    user: userId,
  });

  await product.save();
  res.status(201).send('Product added');
});

app.get('/products', async (req, res) => {
  const products = await Product.find().populate('user');
  res.status(200).json(products);
});

// Serve static images
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Start the server
const port = process.env.PORT || 5000;
app.listen(port, () => console.log(`Server running on http://localhost:${port}`));
