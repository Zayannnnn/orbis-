# Orbis Backend

This is the backend for the Orbis platform, built using Node.js, Express, and MongoDB.

## Features

- User registration and login with password hashing.
- Add products for sale or rent, including image uploads.
- Retrieve all products with user details.

## Setup

1. Clone the repository:
   ```bash
   git clone <repository-url>
   cd orbis-backend
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Create a `.env` file with the following:
   ```env
   MONGO_URI=your_mongo_connection_string
   PORT=5000
   ```

4. Start the server:
   ```bash
   npm start
   ```

## API Endpoints

- `POST /users/register`: Register a new user.
- `POST /users/login`: Login user.
- `POST /products/add`: Add a product (with image upload).
- `GET /products`: Get all products.

## Folder Structure

- `server.js`: Main server file.
- `uploads/`: Directory for uploaded images.
- `.gitignore`: Ignore unnecessary files.
- `README.md`: Project documentation.
